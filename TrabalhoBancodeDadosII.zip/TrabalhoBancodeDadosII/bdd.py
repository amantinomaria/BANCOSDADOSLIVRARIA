import tkinter as tk

from tkinter import ttk, messagebox
import mysql.connector
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from datetime import datetime

# Tela de login modificada
class TelaLogin(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Login - Sistema da Livraria")
        self.geometry("300x250")
        self.resizable(False, False)
        self.configure(bg="#f5f5f5")

        tk.Label(self, text="Usuário:", bg="#f5f5f5").pack(pady=(20, 5))
        self.usuario_entry = tk.Entry(self)
        self.usuario_entry.pack()

        tk.Label(self, text="Senha:", bg="#f5f5f5").pack(pady=(10, 5))
        self.senha_entry = tk.Entry(self, show="*")
        self.senha_entry.pack()

        tk.Label(self, text="Tipo de Usuário:", bg="#f5f5f5").pack(pady=(10, 5))
        self.tipo_usuario = ttk.Combobox(self, values=["Administrador", "Estoquista", "Caixa"], state="readonly")
        self.tipo_usuario.pack()

        tk.Button(self, text="Entrar", command=self.verificar_login).pack(pady=20)

    def verificar_login(self):
        usuario = self.usuario_entry.get()
        senha = self.senha_entry.get()
        tipo = self.tipo_usuario.get()

        # Simulação de banco de dados de usuários
        usuarios = {
            "admin": {"senha": "123", "tipo": "Administrador"},
            "estoque": {"senha": "456", "tipo": "Estoquista"},
            "caixa": {"senha": "789", "tipo": "Caixa"}
        }

        if usuario in usuarios and senha == usuarios[usuario]["senha"] and tipo == usuarios[usuario]["tipo"]:
            self.destroy()
            app = SistemaLivraria(tipo_usuario=tipo)
            app.mainloop()
        else:
            messagebox.showerror("Erro", "Credenciais inválidas ou tipo de usuário incorreto")

# Sistema principal modificado
class SistemaLivraria(tk.Tk):
    def __init__(self, tipo_usuario):
        super().__init__()
        self.tipo_usuario = tipo_usuario
        self.title(f"Sistema Guarapuava Livrarias - {tipo_usuario}")
        self.geometry("1200x800")

        self.menu_frame = tk.Frame(self)
        self.menu_frame.pack(pady=20)

        tk.Label(self.menu_frame, text=f"SELECIONE O MÓDULO ({tipo_usuario})",
                font=("Arial", 14)).pack(pady=10)

        # Dicionário de permissões
        self.permissoes = {
            "Administrador": ["Clientes", "Livros", "Vendas", "Estoque", "Relatórios"],
            "Estoquista": ["Livros", "Estoque"],
            "Caixa": ["Clientes", "Vendas"]
        }

        # Criar botões de acordo com as permissões
        for modulo in self.permissoes[tipo_usuario]:
            tk.Button(self.menu_frame, text=modulo, width=20,
                     command=lambda m=modulo: self.mostrar_modulo(m)).pack(pady=5)

        # Frames dos CRUDs
        self.crud_clientes_frame = None
        self.crud_livros_frame = None
        self.crud_vendas_frame = None
        self.crud_estoque_frame = None
        self.relatorio_frame = None

        try:
            self.conn = mysql.connector.connect(
                host='localhost',
                user='root',
                password='Senh@2709',
                database='bancodedados'
            )
            self.cursor = self.conn.cursor()
        except mysql.connector.Error as e:
            messagebox.showerror("Erro de conexão", f"Erro ao conectar ao banco: {e}")
            self.destroy()

    def mostrar_modulo(self, modulo):
        self.menu_frame.pack_forget()
        self.esconder_todos_frames()

        if modulo == "Clientes":
            if not self.crud_clientes_frame:
                self.crud_clientes_frame = CrudClientes(self, self.conn, self.cursor)
            self.crud_clientes_frame.pack(fill="both", expand=True)
        elif modulo == "Livros":
            if not self.crud_livros_frame:
                self.crud_livros_frame = CrudLivros(self, self.conn, self.cursor)
            self.crud_livros_frame.pack(fill="both", expand=True)
        elif modulo == "Vendas":
            if not self.crud_vendas_frame:
                self.crud_vendas_frame = CrudVendas(self, self.conn, self.cursor)
            self.crud_vendas_frame.pack(fill="both", expand=True)
        elif modulo == "Estoque":
            if not self.crud_estoque_frame:
                self.crud_estoque_frame = CrudEstoque(self, self.conn, self.cursor)
            self.crud_estoque_frame.pack(fill="both", expand=True)
        elif modulo == "Relatórios":
            if not self.relatorio_frame:
                self.relatorio_frame = RelatorioApp(self, self.conn, self.cursor)
            self.relatorio_frame.pack(fill="both", expand=True)

    # ... (o resto da classe permanece igual) ...

    def mostrar_crud_clientes(self):
        self.menu_frame.pack_forget()
        self.esconder_todos_frames()
        if not self.crud_clientes_frame:
            self.crud_clientes_frame = CrudClientes(self, self.conn, self.cursor)
        self.crud_clientes_frame.pack(fill="both", expand=True)

    def mostrar_crud_livros(self):
        self.menu_frame.pack_forget()
        self.esconder_todos_frames()
        if not self.crud_livros_frame:
            self.crud_livros_frame = CrudLivros(self, self.conn, self.cursor)
        self.crud_livros_frame.pack(fill="both", expand=True)

    def mostrar_crud_vendas(self):
        self.menu_frame.pack_forget()
        self.esconder_todos_frames()
        if not self.crud_vendas_frame:
            self.crud_vendas_frame = CrudVendas(self, self.conn, self.cursor)
        self.crud_vendas_frame.pack(fill="both", expand=True)

    def mostrar_crud_estoque(self):
        self.menu_frame.pack_forget()
        self.esconder_todos_frames()
        if not self.crud_estoque_frame:
            self.crud_estoque_frame = CrudEstoque(self, self.conn, self.cursor)
        self.crud_estoque_frame.pack(fill="both", expand=True)

    def mostrar_relatorios(self):
        self.menu_frame.pack_forget()
        self.esconder_todos_frames()
        if not self.relatorio_frame:
            self.relatorio_frame = RelatorioApp(self, self.conn, self.cursor)
        self.relatorio_frame.pack(fill="both", expand=True)

    def esconder_todos_frames(self):
        for frame in [self.crud_clientes_frame, self.crud_livros_frame,
                     self.crud_vendas_frame, self.crud_estoque_frame,
                     self.relatorio_frame]:
            if frame:
                frame.pack_forget()

    def voltar_menu(self):
        self.esconder_todos_frames()
        self.menu_frame.pack(pady=20)

# CRUD de clientes
class CrudClientes(tk.Frame):
    def __init__(self, parent, conn, cursor):
        super().__init__(parent)
        self.parent = parent
        self.conn = conn
        self.cursor = cursor
        self.configure(bg="#2e2e2e")

        self.cpf_var = tk.StringVar()
        self.nome_var = tk.StringVar()
        self.nascimento_var = tk.StringVar()
        self.telefone_var = tk.StringVar()
        self.email_var = tk.StringVar()
        self.cep_var = tk.StringVar()
        self.numero_var = tk.StringVar()

        self.criar_interface()
        self.listar()

    def criar_interface(self):
        labels = ["CPF", "Nome", "Nascimento (AAAA-MM-DD)", "Telefone", "Email", "CEP", "Número"]
        vars_ = [self.cpf_var, self.nome_var, self.nascimento_var, self.telefone_var,
                 self.email_var, self.cep_var, self.numero_var]

        for i, (label, var) in enumerate(zip(labels, vars_)):
            tk.Label(self, text=label, fg="#dcdcdc", bg="#2e2e2e", font=("Arial", 10, "bold")).grid(row=i, column=0, padx=10, pady=5, sticky="e")
            entry = tk.Entry(self, textvariable=var, bg="#444444", fg="#ffffff", insertbackground="#ffffff", width=40, relief="flat")
            entry.grid(row=i, column=1, padx=10, pady=5, sticky="w")

        def criar_botao(txt, cmd, linha):
            return tk.Button(self, text=txt, command=cmd,
                             bg="#a0a0a0", fg="black", activebackground="#909090",
                             font=("Arial", 10, "bold"), relief="flat", width=15).grid(row=linha, column=2, padx=10, pady=5)

        criar_botao("Inserir", self.inserir, 0)
        criar_botao("Atualizar", self.atualizar, 1)
        criar_botao("Deletar", self.deletar, 2)
        criar_botao("Limpar", self.limpar, 3)

        btn_voltar = tk.Button(self, text="Voltar ao Menu", command=self.parent.voltar_menu,
                               bg="#a0a0a0", fg="black", activebackground="#909090",
                               font=("Arial", 10, "bold"), relief="flat", width=15)
        btn_voltar.grid(row=4, column=2, padx=10, pady=15)

        cols = ["CPF", "Nome", "Nascimento", "Telefone", "Email", "CEP", "Número"]
        self.tree = ttk.Treeview(self, columns=cols, show="headings", height=15)
        for col in cols:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=110)
        self.tree.grid(row=8, column=0, columnspan=3, padx=10, pady=20)
        self.tree.bind("<ButtonRelease-1>", self.selecionar)

        estilo = ttk.Style()
        estilo.theme_use("default")
        estilo.configure("Treeview", background="#3c3c3c", foreground="#f0f0f0",
                         fieldbackground="#3c3c3c", rowheight=25)
        estilo.map('Treeview', background=[('selected', '#606060')])
        estilo.configure("Treeview.Heading", background="#a0a0a0", foreground="black")

    def inserir(self):
        try:
            self.cursor.execute("INSERT INTO cliente VALUES (%s, %s, %s, %s, %s, %s, %s)", (
                self.cpf_var.get(),
                self.nome_var.get(),
                self.nascimento_var.get(),
                self.telefone_var.get(),
                self.email_var.get(),
                self.cep_var.get(),
                self.numero_var.get()
            ))
            self.conn.commit()
            self.listar()
            self.limpar()
        except mysql.connector.Error as e:
            messagebox.showerror("Erro", f"Erro ao inserir: {e}")

    def atualizar(self):
        try:
            self.cursor.execute("""UPDATE cliente SET
                nome_completo=%s, data_nascimento=%s, telefone=%s,
                email=%s, cep=%s, numero=%s WHERE cpf=%s""", (
                self.nome_var.get(), self.nascimento_var.get(), self.telefone_var.get(),
                self.email_var.get(), self.cep_var.get(), self.numero_var.get(), self.cpf_var.get()
            ))
            self.conn.commit()
            self.listar()
            self.limpar()
        except mysql.connector.Error as e:
            messagebox.showerror("Erro", f"Erro ao atualizar: {e}")

    def deletar(self):
        try:
            self.cursor.execute("DELETE FROM cliente WHERE cpf=%s", (self.cpf_var.get(),))
            self.conn.commit()
            self.listar()
            self.limpar()
        except mysql.connector.Error as e:
            messagebox.showerror("Erro", f"Erro ao deletar: {e}")

    def listar(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        self.cursor.execute("SELECT * FROM cliente")
        for row in self.cursor.fetchall():
            self.tree.insert("", "end", values=row)

    def selecionar(self, event):
        selected = self.tree.focus()
        if selected:
            values = self.tree.item(selected, 'values')
            self.cpf_var.set(values[0])
            self.nome_var.set(values[1])
            self.nascimento_var.set(values[2])
            self.telefone_var.set(values[3])
            self.email_var.set(values[4])
            self.cep_var.set(values[5])
            self.numero_var.set(values[6])

    def limpar(self):
        for var in (self.cpf_var, self.nome_var, self.nascimento_var, self.telefone_var,
                    self.email_var, self.cep_var, self.numero_var):
            var.set("")

# CRUD de livros
class CrudLivros(tk.Frame):
    def __init__(self, parent, conn, cursor):
        super().__init__(parent)
        self.parent = parent
        self.conn = conn
        self.cursor = cursor
        self.configure(bg="#2e2e2e")

        self.cod_livro_var = tk.StringVar()
        self.titulo_var = tk.StringVar()
        self.autor_var = tk.StringVar()
        self.editora_var = tk.StringVar()
        self.edicao_var = tk.StringVar()
        self.genero_var = tk.StringVar()
        self.paginas_var = tk.StringVar()
        self.preco_var = tk.StringVar()
        self.isbn_var = tk.StringVar()
        self.lote_var = tk.StringVar()

        self.criar_interface()
        self.listar()

    def criar_interface(self):
        labels = ["Código", "Título", "Autor", "Editora", "Edição", "Gênero",
                 "Páginas", "Preço", "ISBN", "Lote"]
        vars_ = [self.cod_livro_var, self.titulo_var, self.autor_var, self.editora_var,
                self.edicao_var, self.genero_var, self.paginas_var, self.preco_var,
                self.isbn_var, self.lote_var]

        for i, (label, var) in enumerate(zip(labels, vars_)):
            tk.Label(self, text=label, fg="#dcdcdc", bg="#2e2e2e", font=("Arial", 10, "bold")).grid(row=i, column=0, padx=10, pady=5, sticky="e")
            entry = tk.Entry(self, textvariable=var, bg="#444444", fg="#ffffff", insertbackground="#ffffff", width=40, relief="flat")
            entry.grid(row=i, column=1, padx=10, pady=5, sticky="w")

        def criar_botao(txt, cmd, linha):
            return tk.Button(self, text=txt, command=cmd,
                             bg="#a0a0a0", fg="black", activebackground="#909090",
                             font=("Arial", 10, "bold"), relief="flat", width=15).grid(row=linha, column=2, padx=10, pady=5)

        criar_botao("Inserir", self.inserir, 0)
        criar_botao("Atualizar", self.atualizar, 1)
        criar_botao("Deletar", self.deletar, 2)
        criar_botao("Limpar", self.limpar, 3)

        btn_voltar = tk.Button(self, text="Voltar ao Menu", command=self.parent.voltar_menu,
                               bg="#a0a0a0", fg="black", activebackground="#909090",
                               font=("Arial", 10, "bold"), relief="flat", width=15)
        btn_voltar.grid(row=4, column=2, padx=10, pady=15)

        cols = ["Código", "Título", "Autor", "Editora", "Edição", "Gênero",
               "Páginas", "Preço", "ISBN", "Lote"]
        self.tree = ttk.Treeview(self, columns=cols, show="headings", height=15)
        for col in cols:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=100)
        self.tree.grid(row=10, column=0, columnspan=3, padx=10, pady=20)
        self.tree.bind("<ButtonRelease-1>", self.selecionar)

        estilo = ttk.Style()
        estilo.theme_use("default")
        estilo.configure("Treeview", background="#3c3c3c", foreground="#f0f0f0",
                         fieldbackground="#3c3c3c", rowheight=25)
        estilo.map('Treeview', background=[('selected', '#606060')])
        estilo.configure("Treeview.Heading", background="#a0a0a0", foreground="black")

    def inserir(self):
        try:
            self.cursor.execute("""
                INSERT INTO livro (titulo, autor, editora, edicao, genero, numero_paginas, preco, isbn, lote_caixa)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                self.titulo_var.get(),
                self.autor_var.get(),
                self.editora_var.get(),
                int(self.edicao_var.get()) if self.edicao_var.get() else None,
                self.genero_var.get(),
                int(self.paginas_var.get()) if self.paginas_var.get() else None,
                float(self.preco_var.get()) if self.preco_var.get() else None,
                self.isbn_var.get(),
                int(self.lote_var.get()) if self.lote_var.get() else None
            ))
            self.conn.commit()
            self.listar()
            self.limpar()
        except mysql.connector.Error as e:
            messagebox.showerror("Erro", f"Erro ao inserir: {e}")

    def atualizar(self):
        try:
            self.cursor.execute("""
                UPDATE livro SET
                titulo=%s, autor=%s, editora=%s, edicao=%s, genero=%s,
                numero_paginas=%s, preco=%s, isbn=%s, lote_caixa=%s
                WHERE cod_livro=%s
            """, (
                self.titulo_var.get(),
                self.autor_var.get(),
                self.editora_var.get(),
                int(self.edicao_var.get()) if self.edicao_var.get() else None,
                self.genero_var.get(),
                int(self.paginas_var.get()) if self.paginas_var.get() else None,
                float(self.preco_var.get()) if self.preco_var.get() else None,
                self.isbn_var.get(),
                int(self.lote_var.get()) if self.lote_var.get() else None,
                int(self.cod_livro_var.get())
            ))
            self.conn.commit()
            self.listar()
            self.limpar()
        except mysql.connector.Error as e:
            messagebox.showerror("Erro", f"Erro ao atualizar: {e}")

    def deletar(self):
        try:
            self.cursor.execute("DELETE FROM livro WHERE cod_livro=%s", (int(self.cod_livro_var.get()),))
            self.conn.commit()
            self.listar()
            self.limpar()
        except mysql.connector.Error as e:
            messagebox.showerror("Erro", f"Erro ao deletar: {e}")

    def listar(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        self.cursor.execute("SELECT * FROM livro")
        for row in self.cursor.fetchall():
            self.tree.insert("", "end", values=row)

    def selecionar(self, event):
        selected = self.tree.focus()
        if selected:
            values = self.tree.item(selected, 'values')
            self.cod_livro_var.set(values[0])
            self.titulo_var.set(values[1])
            self.autor_var.set(values[2])
            self.editora_var.set(values[3])
            self.edicao_var.set(values[4] if values[4] else "")
            self.genero_var.set(values[5] if values[5] else "")
            self.paginas_var.set(values[6] if values[6] else "")
            self.preco_var.set(values[7] if values[7] else "")
            self.isbn_var.set(values[8] if values[8] else "")
            self.lote_var.set(values[9] if values[9] else "")

    def limpar(self):
        for var in (self.cod_livro_var, self.titulo_var, self.autor_var, self.editora_var,
                   self.edicao_var, self.genero_var, self.paginas_var, self.preco_var,
                   self.isbn_var, self.lote_var):
            var.set("")

# CRUD de vendas
class CrudVendas(tk.Frame):
    def __init__(self, parent, conn, cursor):
        super().__init__(parent)
        self.parent = parent
        self.conn = conn
        self.cursor = cursor
        self.configure(bg="#2e2e2e")

        self.cod_venda_var = tk.StringVar()
        self.valor_total_var = tk.StringVar()
        self.data_venda_var = tk.StringVar()
        self.forma_pagamento_var = tk.StringVar()
        self.quantidade_var = tk.StringVar()
        self.item_var = tk.StringVar()
        self.cpf_cliente_var = tk.StringVar()
        self.cod_livro_var = tk.StringVar()

        self.carregar_clientes()
        self.carregar_livros()

        self.criar_interface()
        self.listar()

    def carregar_clientes(self):
        self.cursor.execute("SELECT cpf, nome_completo FROM cliente")
        self.clientes = {row[1]: row[0] for row in self.cursor.fetchall()}

    def carregar_livros(self):
        self.cursor.execute("SELECT cod_livro, titulo FROM livro")
        self.livros = {row[1]: row[0] for row in self.cursor.fetchall()}

    def criar_interface(self):
        labels = ["Código Venda", "Valor Total", "Data (AAAA-MM-DD)", "Forma Pagamento",
                 "Quantidade", "Item", "Cliente", "Livro"]
        vars_ = [self.cod_venda_var, self.valor_total_var, self.data_venda_var,
                self.forma_pagamento_var, self.quantidade_var, self.item_var,
                self.cpf_cliente_var, self.cod_livro_var]

        for i, (label, var) in enumerate(zip(labels, vars_)):
            tk.Label(self, text=label, fg="#dcdcdc", bg="#2e2e2e", font=("Arial", 10, "bold")).grid(row=i, column=0, padx=10, pady=5, sticky="e")

            if label == "Cliente":
                self.cliente_combobox = ttk.Combobox(self, textvariable=var, values=list(self.clientes.keys()), width=37)
                self.cliente_combobox.grid(row=i, column=1, padx=10, pady=5, sticky="w")
            elif label == "Livro":
                self.livro_combobox = ttk.Combobox(self, textvariable=var, values=list(self.livros.keys()), width=37)
                self.livro_combobox.grid(row=i, column=1, padx=10, pady=5, sticky="w")
            else:
                entry = tk.Entry(self, textvariable=var, bg="#444444", fg="#ffffff", insertbackground="#ffffff", width=40, relief="flat")
                entry.grid(row=i, column=1, padx=10, pady=5, sticky="w")

        def criar_botao(txt, cmd, linha):
            return tk.Button(self, text=txt, command=cmd,
                             bg="#a0a0a0", fg="black", activebackground="#909090",
                             font=("Arial", 10, "bold"), relief="flat", width=15).grid(row=linha, column=2, padx=10, pady=5)

        criar_botao("Inserir", self.inserir, 0)
        criar_botao("Atualizar", self.atualizar, 1)
        criar_botao("Deletar", self.deletar, 2)
        criar_botao("Limpar", self.limpar, 3)

        btn_voltar = tk.Button(self, text="Voltar ao Menu", command=self.parent.voltar_menu,
                               bg="#a0a0a0", fg="black", activebackground="#909090",
                               font=("Arial", 10, "bold"), relief="flat", width=15)
        btn_voltar.grid(row=4, column=2, padx=10, pady=15)

        cols = ["Código", "Valor Total", "Data", "Pagamento", "Quantidade", "Item", "CPF Cliente", "Cód. Livro"]
        self.tree = ttk.Treeview(self, columns=cols, show="headings", height=15)
        for col in cols:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=100)
        self.tree.grid(row=8, column=0, columnspan=3, padx=10, pady=20)
        self.tree.bind("<ButtonRelease-1>", self.selecionar)

        estilo = ttk.Style()
        estilo.theme_use("default")
        estilo.configure("Treeview", background="#3c3c3c", foreground="#f0f0f0",
                         fieldbackground="#3c3c3c", rowheight=25)
        estilo.map('Treeview', background=[('selected', '#606060')])
        estilo.configure("Treeview.Heading", background="#a0a0a0", foreground="black")

    def inserir(self):
        try:
            cpf_cliente = self.clientes.get(self.cpf_cliente_var.get())
            cod_livro = self.livros.get(self.cod_livro_var.get())

            if not cpf_cliente or not cod_livro:
                messagebox.showerror("Erro", "Selecione um cliente e um livro válidos")
                return

            self.cursor.execute("""
                INSERT INTO venda (valor_total, data_venda, forma_pagamento, quantidade_vendida, item, cpf_cliente, cod_livro)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """, (
                float(self.valor_total_var.get()),
                self.data_venda_var.get(),
                self.forma_pagamento_var.get(),
                int(self.quantidade_var.get()),
                self.item_var.get(),
                cpf_cliente,
                cod_livro
            ))
            self.conn.commit()
            self.listar()
            self.limpar()
        except mysql.connector.Error as e:
            messagebox.showerror("Erro", f"Erro ao inserir: {e}")

    def atualizar(self):
        try:
            cpf_cliente = self.clientes.get(self.cpf_cliente_var.get())
            cod_livro = self.livros.get(self.cod_livro_var.get())

            if not cpf_cliente or not cod_livro:
                messagebox.showerror("Erro", "Selecione um cliente e um livro válidos")
                return

            self.cursor.execute("""
                UPDATE venda SET
                valor_total=%s, data_venda=%s, forma_pagamento=%s,
                quantidade_vendida=%s, item=%s, cpf_cliente=%s, cod_livro=%s
                WHERE cod_venda=%s
            """, (
                float(self.valor_total_var.get()),
                self.data_venda_var.get(),
                self.forma_pagamento_var.get(),
                int(self.quantidade_var.get()),
                self.item_var.get(),
                cpf_cliente,
                cod_livro,
                int(self.cod_venda_var.get())
            ))
            self.conn.commit()
            self.listar()
            self.limpar()
        except mysql.connector.Error as e:
            messagebox.showerror("Erro", f"Erro ao atualizar: {e}")

    def deletar(self):
        try:
            self.cursor.execute("DELETE FROM venda WHERE cod_venda=%s", (int(self.cod_venda_var.get()),))
            self.conn.commit()
            self.listar()
            self.limpar()
        except mysql.connector.Error as e:
            messagebox.showerror("Erro", f"Erro ao deletar: {e}")

    def listar(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        self.cursor.execute("SELECT * FROM venda")
        for row in self.cursor.fetchall():
            self.tree.insert("", "end", values=row)

    def selecionar(self, event):
        selected = self.tree.focus()
        if selected:
            values = self.tree.item(selected, 'values')
            self.cod_venda_var.set(values[0])
            self.valor_total_var.set(values[1])
            self.data_venda_var.set(values[2])
            self.forma_pagamento_var.set(values[3])
            self.quantidade_var.set(values[4])
            self.item_var.set(values[5])

            self.cursor.execute("SELECT nome_completo FROM cliente WHERE cpf=%s", (values[6],))
            cliente = self.cursor.fetchone()
            self.cpf_cliente_var.set(cliente[0] if cliente else "")

            self.cursor.execute("SELECT titulo FROM livro WHERE cod_livro=%s", (int(values[7]),))
            livro = self.cursor.fetchone()
            self.cod_livro_var.set(livro[0] if livro else "")

    def limpar(self):
        for var in (self.cod_venda_var, self.valor_total_var, self.data_venda_var,
                   self.forma_pagamento_var, self.quantidade_var, self.item_var,
                   self.cpf_cliente_var, self.cod_livro_var):
            var.set("")

# CRUD de estoque
class CrudEstoque(tk.Frame):
    def __init__(self, parent, conn, cursor):
        super().__init__(parent)
        self.parent = parent
        self.conn = conn
        self.cursor = cursor
        self.configure(bg="#2e2e2e")

        self.cod_livro_var = tk.StringVar()
        self.cnpj_fornecedor_var = tk.StringVar()
        self.quantidade_var = tk.StringVar()
        self.lote_var = tk.StringVar()

        self.carregar_livros()
        self.carregar_fornecedores()

        self.criar_interface()
        self.listar()

    def carregar_livros(self):
        self.cursor.execute("SELECT cod_livro, titulo FROM livro")
        self.livros = {row[1]: row[0] for row in self.cursor.fetchall()}

    def carregar_fornecedores(self):
        self.cursor.execute("SELECT cnpj_fornecedor, nome FROM fornecedor")
        self.fornecedores = {row[1]: row[0] for row in self.cursor.fetchall()}

    def criar_interface(self):
        labels = ["Livro", "Fornecedor", "Quantidade", "Lote"]
        vars_ = [self.cod_livro_var, self.cnpj_fornecedor_var,
                self.quantidade_var, self.lote_var]

        for i, (label, var) in enumerate(zip(labels, vars_)):
            tk.Label(self, text=label, fg="#dcdcdc", bg="#2e2e2e", font=("Arial", 10, "bold")).grid(row=i, column=0, padx=10, pady=5, sticky="e")

            if label == "Livro":
                self.livro_combobox = ttk.Combobox(self, textvariable=var, values=list(self.livros.keys()), width=37)
                self.livro_combobox.grid(row=i, column=1, padx=10, pady=5, sticky="w")
            elif label == "Fornecedor":
                self.fornecedor_combobox = ttk.Combobox(self, textvariable=var, values=list(self.fornecedores.keys()), width=37)
                self.fornecedor_combobox.grid(row=i, column=1, padx=10, pady=5, sticky="w")
            else:
                entry = tk.Entry(self, textvariable=var, bg="#444444", fg="#ffffff", insertbackground="#ffffff", width=40, relief="flat")
                entry.grid(row=i, column=1, padx=10, pady=5, sticky="w")

        def criar_botao(txt, cmd, linha):
            return tk.Button(self, text=txt, command=cmd,
                             bg="#a0a0a0", fg="black", activebackground="#909090",
                             font=("Arial", 10, "bold"), relief="flat", width=15).grid(row=linha, column=2, padx=10, pady=5)

        criar_botao("Inserir", self.inserir, 0)
        criar_botao("Atualizar", self.atualizar, 1)
        criar_botao("Deletar", self.deletar, 2)
        criar_botao("Limpar", self.limpar, 3)

        btn_voltar = tk.Button(self, text="Voltar ao Menu", command=self.parent.voltar_menu,
                               bg="#a0a0a0", fg="black", activebackground="#909090",
                               font=("Arial", 10, "bold"), relief="flat", width=15)
        btn_voltar.grid(row=4, column=2, padx=10, pady=15)

        cols = ["Cód. Livro", "CNPJ Fornecedor", "Quantidade", "Lote"]
        self.tree = ttk.Treeview(self, columns=cols, show="headings", height=15)
        for col in cols:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=120)
        self.tree.grid(row=5, column=0, columnspan=3, padx=10, pady=20)
        self.tree.bind("<ButtonRelease-1>", self.selecionar)

        estilo = ttk.Style()
        estilo.theme_use("default")
        estilo.configure("Treeview", background="#3c3c3c", foreground="#f0f0f0",
                         fieldbackground="#3c3c3c", rowheight=25)
        estilo.map('Treeview', background=[('selected', '#606060')])
        estilo.configure("Treeview.Heading", background="#a0a0a0", foreground="black")

    def inserir(self):
        try:
            cod_livro = self.livros.get(self.cod_livro_var.get())
            cnpj_fornecedor = self.fornecedores.get(self.cnpj_fornecedor_var.get())

            if not cod_livro or not cnpj_fornecedor:
                messagebox.showerror("Erro", "Selecione um livro e um fornecedor válidos")
                return

            self.cursor.execute("""
                INSERT INTO estoque (cod_livro, cnpj_fornecedor, quantidade_estoque, lote_caixa)
                VALUES (%s, %s, %s, %s)
            """, (
                cod_livro,
                cnpj_fornecedor,
                int(self.quantidade_var.get()),
                int(self.lote_var.get()) if self.lote_var.get() else None
            ))
            self.conn.commit()
            self.listar()
            self.limpar()
        except mysql.connector.Error as e:
            messagebox.showerror("Erro", f"Erro ao inserir: {e}")

    def atualizar(self):
        try:
            cod_livro = self.livros.get(self.cod_livro_var.get())
            cnpj_fornecedor = self.fornecedores.get(self.cnpj_fornecedor_var.get())

            if not cod_livro or not cnpj_fornecedor:
                messagebox.showerror("Erro", "Selecione um livro e um fornecedor válidos")
                return

            self.cursor.execute("""
                UPDATE estoque SET
                quantidade_estoque=%s, lote_caixa=%s
                WHERE cod_livro=%s AND cnpj_fornecedor=%s
            """, (
                int(self.quantidade_var.get()),
                int(self.lote_var.get()) if self.lote_var.get() else None,
                cod_livro,
                cnpj_fornecedor
            ))
            self.conn.commit()
            self.listar()
            self.limpar()
        except mysql.connector.Error as e:
            messagebox.showerror("Erro", f"Erro ao atualizar: {e}")

    def deletar(self):
        try:
            cod_livro = self.livros.get(self.cod_livro_var.get())
            cnpj_fornecedor = self.fornecedores.get(self.cnpj_fornecedor_var.get())

            if not cod_livro or not cnpj_fornecedor:
                messagebox.showerror("Erro", "Selecione um livro e um fornecedor válidos")
                return

            self.cursor.execute("DELETE FROM estoque WHERE cod_livro=%s AND cnpj_fornecedor=%s",
                              (cod_livro, cnpj_fornecedor))
            self.conn.commit()
            self.listar()
            self.limpar()
        except mysql.connector.Error as e:
            messagebox.showerror("Erro", f"Erro ao deletar: {e}")

    def listar(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        self.cursor.execute("SELECT * FROM estoque")
        for row in self.cursor.fetchall():
            self.tree.insert("", "end", values=row)

    def selecionar(self, event):
        selected = self.tree.focus()
        if selected:
            values = self.tree.item(selected, 'values')

            self.cursor.execute("SELECT titulo FROM livro WHERE cod_livro=%s", (int(values[0]),))
            livro = self.cursor.fetchone()
            self.cod_livro_var.set(livro[0] if livro else "")

            self.cursor.execute("SELECT nome FROM fornecedor WHERE cnpj_fornecedor=%s", (values[1],))
            fornecedor = self.cursor.fetchone()
            self.cnpj_fornecedor_var.set(fornecedor[0] if fornecedor else "")

            self.quantidade_var.set(values[2])
            self.lote_var.set(values[3] if values[3] else "")

    def limpar(self):
        for var in (self.cod_livro_var, self.cnpj_fornecedor_var,
                   self.quantidade_var, self.lote_var):
            var.set("")

# Relatórios
class RelatorioApp(tk.Frame):
    def __init__(self, parent, conn, cursor):
        super().__init__(parent)
        self.parent = parent
        self.conn = conn
        self.cursor = cursor
        self.tipo_relatorio = tk.StringVar(value="livros_mais_vendidos")
        self.criar_interface()

    def criar_interface(self):
        frame_selecao = ttk.LabelFrame(self, text="Opções de Relatório", padding=10)
        frame_selecao.pack(pady=10, padx=10, fill="x")

        opcoes = [
            ("Livros Mais Vendidos", "livros_mais_vendidos"),
            ("Vendas por Forma de Pagamento", "vendas_por_pagamento"),
            ("Estoque Baixo", "estoque_baixo"),
            ("Top 5 Clientes", "top_clientes"),
            ("Vendas por Mês", "vendas_por_mes")
        ]

        for text, value in opcoes:
            rb = ttk.Radiobutton(frame_selecao, text=text, variable=self.tipo_relatorio, value=value)
            rb.pack(anchor="w", pady=2)

        ttk.Button(frame_selecao, text="Gerar Relatório", command=self.gerar_relatorio).pack(pady=10)
        ttk.Button(self, text="Voltar ao Menu", command=self.parent.voltar_menu).pack(pady=5)

        self.frame_grafico = ttk.Frame(self)
        self.frame_grafico.pack(expand=True, fill="both", padx=10, pady=10)

    def gerar_relatorio(self):
        for widget in self.frame_grafico.winfo_children():
            widget.destroy()

        tipo = self.tipo_relatorio.get()

        if tipo == "livros_mais_vendidos":
            self.relatorio_livros_mais_vendidos()
        elif tipo == "vendas_por_pagamento":
            self.relatorio_vendas_por_pagamento()
        elif tipo == "estoque_baixo":
            self.relatorio_estoque_baixo()
        elif tipo == "top_clientes":
            self.relatorio_top_clientes()
        elif tipo == "vendas_por_mes":
            self.relatorio_vendas_por_mes()

    def relatorio_livros_mais_vendidos(self):
        query = """
        SELECT livro.titulo, SUM(venda.quantidade_vendida) as total
        FROM venda
        JOIN livro ON venda.cod_livro = livro.cod_livro
        GROUP BY livro.titulo ORDER BY total DESC LIMIT 10
        """
        try:
            self.cursor.execute(query)
            dados = self.cursor.fetchall()
            if not dados:
                messagebox.showinfo("Info", "Nenhum dado para este relatório.")
                return

            titulos = [d[0] for d in dados]
            totais = [d[1] for d in dados]

            fig, ax = plt.subplots(figsize=(8, 4))
            ax.barh(titulos[::-1], totais[::-1], color="skyblue")
            ax.set_title("Top 10 Livros Mais Vendidos")
            ax.set_xlabel("Quantidade Vendida")
            fig.tight_layout()

            canvas = FigureCanvasTkAgg(fig, master=self.frame_grafico)
            canvas.draw()
            canvas.get_tk_widget().pack(expand=True, fill='both')
        except mysql.connector.Error as e:
            messagebox.showerror("Erro", f"Erro ao gerar relatório: {e}")

    def relatorio_vendas_por_pagamento(self):
        query = "SELECT forma_pagamento, COUNT(*) FROM venda GROUP BY forma_pagamento"
        self.cursor.execute(query)
        dados = self.cursor.fetchall()
        if not dados:
            messagebox.showinfo("Info", "Nenhum dado para este relatório.")
            return

        formas = [d[0] for d in dados]
        counts = [d[1] for d in dados]

        fig, ax = plt.subplots(figsize=(6, 6))
        ax.pie(counts, labels=formas, autopct='%1.1f%%', startangle=140)
        ax.set_title("Vendas por Forma de Pagamento")

        canvas = FigureCanvasTkAgg(fig, master=self.frame_grafico)
        canvas.draw()
        canvas.get_tk_widget().pack(expand=True, fill='both')

    def relatorio_estoque_baixo(self):
        query = """
        SELECT livro.titulo, estoque.quantidade_estoque
        FROM estoque
        JOIN livro ON estoque.cod_livro = livro.cod_livro
        WHERE estoque.quantidade_estoque < 5
        """
        self.cursor.execute(query)
        dados = self.cursor.fetchall()
        if not dados:
            messagebox.showinfo("Info", "Nenhum livro com estoque baixo.")
            return

        titulos = [d[0] for d in dados]
        qtds = [d[1] for d in dados]

        fig, ax = plt.subplots(figsize=(8, 4))
        ax.bar(titulos, qtds, color="tomato")
        ax.set_title("Livros com Estoque Baixo (<5 unidades)")
        ax.set_ylabel("Quantidade em Estoque")
        ax.set_xticklabels(titulos, rotation=45, ha='right')
        fig.tight_layout()

        canvas = FigureCanvasTkAgg(fig, master=self.frame_grafico)
        canvas.draw()
        canvas.get_tk_widget().pack(expand=True, fill='both')

    def relatorio_top_clientes(self):
        query = """
        SELECT c.nome_completo, SUM(v.valor_total) as total
        FROM venda v
        JOIN cliente c ON v.cpf_cliente = c.cpf
        GROUP BY c.nome_completo ORDER BY total DESC LIMIT 5
        """
        self.cursor.execute(query)
        dados = self.cursor.fetchall()
        if not dados:
            messagebox.showinfo("Info", "Nenhum dado para este relatório.")
            return

        clientes = [d[0] for d in dados]
        valores = [float(d[1]) for d in dados]

        fig, ax = plt.subplots(figsize=(8, 4))
        ax.barh(clientes[::-1], valores[::-1], color="lightgreen")
        ax.set_title("Top 5 Clientes por Valor Gasto")
        ax.set_xlabel("Valor Total (R$)")
        fig.tight_layout()

        canvas = FigureCanvasTkAgg(fig, master=self.frame_grafico)
        canvas.draw()
        canvas.get_tk_widget().pack(expand=True, fill='both')

    def relatorio_vendas_por_mes(self):
        query = """
        SELECT DATE_FORMAT(data_venda, '%Y-%m') as mes, SUM(valor_total)
        FROM venda
        GROUP BY mes ORDER BY mes
        """
        self.cursor.execute(query)
        dados = self.cursor.fetchall()
        if not dados:
            messagebox.showinfo("Info", "Nenhum dado para este relatório.")
            return

        meses = [d[0] for d in dados]
        valores = [float(d[1]) for d in dados]

        fig, ax = plt.subplots(figsize=(8, 4))
        ax.plot(meses, valores, marker='o')
        ax.set_title("Vendas por Mês")
        ax.set_xlabel("Mês")
        ax.set_ylabel("Valor Total (R$)")
        ax.tick_params(axis='x', rotation=45)
        fig.tight_layout()

        canvas = FigureCanvasTkAgg(fig, master=self.frame_grafico)
        canvas.draw()
        canvas.get_tk_widget().pack(expand=True, fill='both')

if __name__ == "__main__":
    login = TelaLogin()
    login.mainloop()